"use client";

import {
  FormEvent,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { CloudSun, Send, WifiOff } from "lucide-react";

type Role = "user" | "assistant";

type Msg = {
  id: string;
  role: Role;
  content: string;
  time: string;
  isError?: boolean;
};

type WeatherSummary = {
  temperature: number;
  precipitation: number;
  windMax: number;
};

const WELCOME_ID = "welcome";
const MAX_HISTORY = 10;

const WELCOME: Msg = {
  id: WELCOME_ID,
  role: "assistant",
  content:
    "السلام عليكم! أنا TerraMind 🌱 المستشار الفلاحي ديالك. سولني على السقي وأنا نجاوبك على حساب طقس مراكش دابا.",
  time: "",
};

const SUGGESTIONS = [
  "واش نسقي الطماطم اليوم؟",
  "شحال ديال الما نعطي للنعناع؟",
  "فوقاش نسقي الزيتون؟",
];

function nowLabel() {
  return new Date().toLocaleTimeString("ar-MA", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function ChatBox() {
  const [messages, setMessages] = useState<Msg[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [online, setOnline] = useState(true);
  const [weather, setWeather] = useState<WeatherSummary | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const counter = useRef(0);

  const nextId = () => `m-${Date.now()}-${counter.current++}`;

  // Auto-scroll on new message or typing indicator
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, loading]);

  // Connectivity status
  useEffect(() => {
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || loading) return;

      const userMsg: Msg = {
        id: nextId(),
        role: "user",
        content: text,
        time: nowLabel(),
      };

      // History sent to the API: skip welcome + error bubbles
      const history = [...messages, userMsg]
        .filter((m) => m.id !== WELCOME_ID && !m.isError)
        .slice(-MAX_HISTORY)
        .map(({ role, content }) => ({ role, content }));

      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setLoading(true);

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: history }),
        });

        const data = await res.json().catch(() => ({}));

        if (!res.ok || !data.reply) {
          setMessages((prev) => [
            ...prev,
            {
              id: nextId(),
              role: "assistant",
              content: data.error ?? "وقع مشكل. عاود حاول من بعد.",
              time: nowLabel(),
              isError: true,
            },
          ]);
          return;
        }

        if (data.weather) setWeather(data.weather);
        setMessages((prev) => [
          ...prev,
          {
            id: nextId(),
            role: "assistant",
            content: data.reply,
            time: nowLabel(),
          },
        ]);
      } catch {
        setMessages((prev) => [
          ...prev,
          {
            id: nextId(),
            role: "assistant",
            content: "ما قدرتش نتصل بالسيرفر. شوف الإنترنت ديالك وعاود حاول.",
            time: nowLabel(),
            isError: true,
          },
        ]);
      } finally {
        setLoading(false);
        inputRef.current?.focus();
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [messages, loading]
  );

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    send(input);
  }

  const showSuggestions = messages.length === 1 && !loading;

  return (
    <div className="flex h-full flex-col" dir="rtl">
      {/* Header */}
      <header className="flex items-center gap-3 bg-[#075e54] px-4 py-3 text-white shadow-md dark:bg-[#202c33]">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/15 text-2xl">
          🌱
        </div>

        <div className="min-w-0 flex-1 leading-tight">
          <h1 className="text-lg font-bold">TerraMind 🌱</h1>
          <p className="mt-0.5 flex items-center gap-1.5 text-xs text-white/80">
            {online ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-300 opacity-60 motion-reduce:animate-none" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                {loading ? "كيكتب..." : "متصل • مراكش"}
              </>
            ) : (
              <>
                <WifiOff className="h-3 w-3" aria-hidden="true" />
                ما كاينش الإنترنت
              </>
            )}
          </p>
        </div>

        {weather && (
          <div
            className="flex shrink-0 items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-sm font-medium"
            title="طقس مراكش دابا"
          >
            <CloudSun className="h-4 w-4" aria-hidden="true" />
            <span dir="ltr">{Math.round(weather.temperature)}°C</span>
          </div>
        )}
      </header>

      {/* Messages */}
      <div
        className="flex flex-1 flex-col gap-1.5 overflow-y-auto px-3 py-4"
        role="log"
        aria-live="polite"
      >
        {messages.map((m) => {
          const isUser = m.role === "user";
          return (
            <div
              key={m.id}
              className={[
                "max-w-[82%] whitespace-pre-wrap break-words rounded-xl px-3 py-2 text-[15px] leading-relaxed shadow-sm",
                isUser
                  ? "self-start rounded-ss-none bg-[#d9fdd3] text-gray-900 dark:bg-[#005c4b] dark:text-[#e9edef]"
                  : m.isError
                    ? "self-end rounded-se-none border border-red-300 bg-red-50 text-red-900 dark:border-red-500/40 dark:bg-red-950/50 dark:text-red-200"
                    : "self-end rounded-se-none bg-white text-gray-900 dark:bg-[#202c33] dark:text-[#e9edef]",
              ].join(" ")}
            >
              {m.content}
              {m.time && (
                <span className="mt-1 block text-end text-[10px] text-gray-500 dark:text-[#8696a0]">
                  {m.time}
                </span>
              )}
            </div>
          );
        })}

        {/* Typing indicator */}
        {loading && (
          <div
            className="self-end rounded-xl rounded-se-none bg-white px-4 py-3.5 shadow-sm dark:bg-[#202c33]"
            aria-label="كيكتب"
          >
            <span className="flex items-center gap-1" dir="ltr">
              <span className="h-2 w-2 animate-bounce rounded-full bg-gray-400 [animation-delay:-0.3s] dark:bg-[#8696a0]" />
              <span className="h-2 w-2 animate-bounce rounded-full bg-gray-400 [animation-delay:-0.15s] dark:bg-[#8696a0]" />
              <span className="h-2 w-2 animate-bounce rounded-full bg-gray-400 dark:bg-[#8696a0]" />
            </span>
          </div>
        )}

        {/* Quick suggestions */}
        {showSuggestions && (
          <div className="mt-2 flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => send(s)}
                className="rounded-full border border-[#075e54]/30 bg-white px-3.5 py-2 text-sm text-[#075e54] transition-colors active:bg-gray-100 dark:border-[#00a884]/40 dark:bg-[#202c33] dark:text-[#00a884] dark:active:bg-[#2a3942]"
              >
                {s}
              </button>
            ))}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <form
        onSubmit={onSubmit}
        className="flex items-center gap-2 bg-[#f0f2f5] px-3 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] dark:bg-[#202c33]"
      >
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="كتب سؤالك هنا..."
          maxLength={500}
          autoComplete="off"
          enterKeyHint="send"
          className="min-w-0 flex-1 rounded-full bg-white px-4 py-3 text-base text-gray-900 outline-none placeholder:text-gray-400 focus-visible:ring-2 focus-visible:ring-[#00a884] dark:bg-[#2a3942] dark:text-[#e9edef] dark:placeholder:text-[#8696a0]"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          aria-label="إرسال"
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#00a884] text-white transition-opacity focus-visible:ring-2 focus-visible:ring-[#00a884] focus-visible:ring-offset-2 disabled:opacity-50"
        >
          {/* Mirrored so the arrow points left in RTL */}
          <Send className="h-5 w-5 -scale-x-100" aria-hidden="true" />
        </button>
      </form>
    </div>
  );
}
