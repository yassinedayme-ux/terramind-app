import ChatBox from "@/components/ChatBox";

export default function Home() {
  return (
    <main className="mx-auto h-dvh w-full max-w-md overflow-hidden bg-[#efeae2] shadow-2xl dark:bg-[#0b141a] sm:border-x sm:border-black/10 dark:sm:border-white/10">
      <ChatBox />
    </main>
  );
}
