import type { Metadata, Viewport } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-cairo",
  display: "swap",
});

export const metadata: Metadata = {
  title: "TerraMind 🌱 | المستشار الفلاحي",
  description: "مساعد ذكي للفلاحين المغاربة: نصائح السقي حسب الطقس.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#075e54" },
    { media: "(prefers-color-scheme: dark)", color: "#202c33" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl">
      <body
        className={`${cairo.variable} bg-neutral-200 font-sans antialiased dark:bg-black`}
      >
        {children}
      </body>
    </html>
  );
}
