import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MARRAKECH = { lat: 31.6295, lon: -7.9811 };
const MAX_HISTORY = 10;
const MAX_CONTENT_LENGTH = 500;

const SYSTEM_PROMPT =
  "You are an expert Moroccan agricultural consultant. You must reply in Moroccan Darija (Arabic script). Keep your answers extremely brief (max 2-3 sentences). Be highly practical. You will receive weather data; use it to answer the farmer's question about whether to irrigate today, how much water, and at what time.";

type ChatMessage = { role: "user" | "assistant"; content: string };

type Weather = {
  localTime: string;
  temperature: number;
  precipitation: number;
  windSpeed: number;
  tempMax: number;
  rainSum: number;
  windMax: number;
  et0: number | null;
};

class WeatherError extends Error {}

/* ---------- Helpers ---------- */

function sanitizeMessages(raw: unknown): ChatMessage[] | null {
  if (!Array.isArray(raw) || raw.length === 0) return null;

  const cleaned: ChatMessage[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") return null;
    const { role, content } = item as Record<string, unknown>;
    if (role !== "user" && role !== "assistant") return null;
    if (typeof content !== "string") return null;
    const text = content.trim();
    if (!text) continue;
    cleaned.push({ role, content: text.slice(0, MAX_CONTENT_LENGTH) });
  }

  const trimmed = cleaned.slice(-MAX_HISTORY);
  if (trimmed.length === 0 || trimmed[trimmed.length - 1].role !== "user") {
    return null;
  }
  return trimmed;
}

async function getWeather(): Promise<Weather> {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(MARRAKECH.lat));
  url.searchParams.set("longitude", String(MARRAKECH.lon));
  url.searchParams.set(
    "current",
    "temperature_2m,precipitation,wind_speed_10m"
  );
  url.searchParams.set(
    "daily",
    "temperature_2m_max,precipitation_sum,wind_speed_10m_max,et0_fao_evapotranspiration"
  );
  url.searchParams.set("timezone", "Africa/Casablanca");
  url.searchParams.set("forecast_days", "1");

  let res: Response;
  try {
    res = await fetch(url.toString(), {
      cache: "no-store",
      signal: AbortSignal.timeout(8000),
    });
  } catch {
    throw new WeatherError("Open-Meteo unreachable");
  }
  if (!res.ok) throw new WeatherError(`Open-Meteo status ${res.status}`);

  const data = await res.json();
  const c = data?.current;
  const d = data?.daily;
  if (!c || !d) throw new WeatherError("Open-Meteo malformed response");

  return {
    localTime: c.time,
    temperature: c.temperature_2m,
    precipitation: c.precipitation,
    windSpeed: c.wind_speed_10m,
    tempMax: d.temperature_2m_max?.[0],
    rainSum: d.precipitation_sum?.[0],
    windMax: d.wind_speed_10m_max?.[0],
    et0: d.et0_fao_evapotranspiration?.[0] ?? null,
  };
}

function buildWeatherContext(w: Weather): string {
  return [
    "Live weather data for Marrakech (source: Open-Meteo):",
    `- Local time now: ${w.localTime}`,
    `- Temperature now: ${w.temperature}°C (today's max: ${w.tempMax}°C)`,
    `- Precipitation now: ${w.precipitation} mm (expected total today: ${w.rainSum} mm)`,
    `- Wind speed now: ${w.windSpeed} km/h (today's max: ${w.windMax} km/h)`,
    w.et0 !== null
      ? `- Reference evapotranspiration (ET0) today: ${w.et0} mm`
      : null,
  ]
    .filter(Boolean)
    .join("\n");
}

function errorResponse(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

/* ---------- Route ---------- */

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return errorResponse("الطلب ماكيناش صحيح.", 400);
  }

  const messages = sanitizeMessages((body as { messages?: unknown })?.messages);
  if (!messages) {
    return errorResponse("كتب سؤالك وعاود صيفطو.", 400);
  }

  if (!process.env.OPENAI_API_KEY) {
    console.error("[/api/chat] OPENAI_API_KEY is missing");
    return errorResponse("السيرفر ماشي مهيأ مزيان. عاود من بعد.", 500);
  }

  try {
    const weather = await getWeather();

    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
      timeout: 20_000,
      maxRetries: 1,
    });

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_tokens: 250,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "system", content: buildWeatherContext(weather) },
        ...messages,
      ],
    });

    const reply =
      completion.choices[0]?.message?.content?.trim() ||
      "سمح ليا، ما قدرتش نجاوب دابا. عاود سولني.";

    return NextResponse.json({
      reply,
      weather: {
        temperature: weather.temperature,
        precipitation: weather.precipitation,
        windMax: weather.windMax,
      },
    });
  } catch (err) {
    console.error("[/api/chat]", err);

    if (err instanceof WeatherError) {
      return errorResponse(
        "ما قدرتش نجيب معلومات الطقس دابا. عاود حاول من بعد شوية.",
        502
      );
    }
    if (err instanceof OpenAI.APIError) {
      if (err.status === 429) {
        return errorResponse(
          "كاين ضغط كبير دابا على المساعد. عاود حاول من بعد دقيقة.",
          429
        );
      }
      if (err.status === 401) {
        return errorResponse("مشكل فإعدادات السيرفر. عاود من بعد.", 500);
      }
    }
    return errorResponse("وقع مشكل فالمساعد. عاود حاول من بعد.", 500);
  }
}
